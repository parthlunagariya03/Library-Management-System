String pswrd = new String(Password.getPassword());
    String username = User.getText();
    String query = "SELECT PASSWORD FROM admin WHERE USER_ID = ?";

        try {
            Connection conn = DriverManager.getConnection(url, mysqluser, mysqlpwd);
            PreparedStatement stm = conn.prepareStatement(query);
            stm.setString(1, username);
            ResultSet rs = stm.executeQuery();

            if (rs.next()) {
                String realpswrd = rs.getString("PASSWORD");

                if (realpswrd.equals(pswrd)) {
                    Dashboard dsh = new Dashboard();
                    dsh.setVisible(true);
                    this.dispose(); // Close the login frame
                } else {
                    JOptionPane.showMessageDialog(null, "Invalid username or password", "Error", JOptionPane.ERROR_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(null, "Invalid username or password", "Error", JOptionPane.ERROR_MESSAGE);
            }

            // Close resources
            rs.close();
            stm.close();
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(null, "Database connection error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }	
        }